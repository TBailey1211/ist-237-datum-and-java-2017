//Taylor Bailey

document.write("Astro Boy (2009) is one of my favorite movies that I've watched recently!")
document.write(" It is about a young boy named Toby Tenma, the son of a brilliant inventor who works as the head of the Minestry of Science in a city in the sky called Metro City.")
document.write(" An accident occurs at Dr. Tenma's laboratory that results in his son's death. Devestated by the incident, he vows to bring him back in any way that he can.")
document.write(" The scientists had been researching a new type of energy from a fallen meteorite they dubbed 'blue core energy'. Dr. Tenma uses this energy to bring Toby back to life as a robot.")
document.write(" And thus, Astro Boy is born.<br>")
document.write(" Toby spends the movie dealing with his new life as a robot, the fact that his father struggles to accept him as his son upon realizing he can no longer grow older like a normal child, and learn what it means to become a true hero.<br>")